Please change all values in the config file to their respective ones
ie.
user | your username
bg | the colour of your background
member_list | disables the member list (is only meant to be used under low bandwidth areas)
url | determines the server you connect to, examples: https://cserver.qr0n.repl.co
however servers can be hosted by you and anyone else, but the software i shall keep locked.
 